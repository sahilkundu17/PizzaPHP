
<head>
</head>

<!-- Far Left Column, nav, search, etc.-->
<div id="leftcol">
  <!-- Sub Navigation-->
  <div id="subnav">
        <!-- TemplateBeginIf cond="subnav1" -->
    <!-- Resources -->
    <!-- TemplateBeginIf cond="resources" --><!-- TemplateBeginEditable name="EditRegion7" -->
   <div class="quick">
          <a href="https://services.jsatech.com/index.php?cid=54">
             <img src="/corsijn/pizza/images/deposit.jpg" width="185" height="137" />
          </a>
	</div>

    <!-- TemplateBeginIf cond="resources" --><!-- TemplateBeginEditable name="EditRegion7" -->
	<div class="quick">
		<h2>QUICK LINKS</h2>
   <span style="background: url(http://foodservices.appstate.edu/sites/all/modules/extlink/extlink.png) right center no-repeat;" />

		<p style="margin-left: 10px;"> 
   <ul>
                <li><a href="http://appcard.appstate.edu"> AppCard </a></li>
                <li><a href="http://foodservices.appstate.edu/appcard/meal-plans"> Meal Accounts </a></li>
                <li><a href="http://foodservices.appstate.edu/dining/menus"> Dining Facilities & Menus </a></li>
                <li><a href="http://foodservices.appstate.edu/dining/nutrition-resources"> Nutrition Resources </a></li>
                <li><a href="http://foodservices.appstate.edu/dining/operating-schedules"> Operating Schedules </a></li>
                <li><a href="http://foodservices.appstate.edu/dining/price-comparisons-local-restaurants"> Price Comparison </a></li>
                <li><a href="http://foodservices.appstate.edu/dining/refund-policy"> Refund Policy </a></li>
                <li><a href="http://foodservices.appstate.edu/about/employment-opportunities"> Student Employment </a></li>
   </ul>

       </p>         
          	</div>

<div class="quick" id="food-calendar">
<iframe src="http://foodservices.appstate.edu/pizzeria #block-views-appalachian_calendar-block_1" scrolling="no" width="100%" height="100%"></iframe>
</div>


    <div class="quick">
   <h2>CONTACT</h2>
    <p>
      <strong>Mailing Address</strong>
<br> 
      Appalachian Food Services
<br> 
      P.O. Box 32061
<br> 
      Boone, NC, 28608 USA
<br> 
      828-262-3061</p>

   <p>
     <strong>Physical Address</strong> 
<br> 
     Appalachian Food Services
<br> 
     170 Stadium Drive
<br> 
     Boone, NC, 28608 USA
<br> 
     828-262-3061</p>
    </div>
    <!-- TemplateEndEditable --><!-- TemplateEndIf -->
    <!-- end left column -->
  </div>
</div>

