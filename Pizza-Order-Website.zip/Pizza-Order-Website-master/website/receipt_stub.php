<?php
    include_once('connect.php');
    include_once('constants.php');
    include_once('receipt_methods.php');
?>

<head>
    <link rel="stylesheet" type="text/css" href="receipt.css">
</head>


<div id="receiptItems" class="receiptItem"></div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/receipt.js"></script> 
