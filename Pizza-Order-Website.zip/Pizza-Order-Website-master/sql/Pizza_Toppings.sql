CREATE TABLE IF NOT EXISTS Pizza_Toppings
(
    pizzaId INT (4) NOT NULL,
    toppingId INT(4) NOT NULL
);

